# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

bl_info = {
    "name": "Book Generator",
    "author": "Updated by Mersh, originally by Lell, Anfeo",
    "version": (0, 0, 1),
    "blender": (2, 80, 0),
    "location": "3D View",
    "description": "Book Wizard",
    "category": "3D View"
}

import bpy
import bmesh
import random
import bpy.utils.previews
import os
from mathutils import Vector, Matrix
from bpy.props import *
from bpy.types import (Panel,Menu,Operator,PropertyGroup)

from . ui.panels import OBJECT_BooksGenerator

# Global addon properties
class BWProperties(PropertyGroup):
    
    gen_seed: IntProperty(
        name = "Seed",
        description = "Input a seed for book generation",
        default = 12345,
    )

# Registration
classes = (

    # Properties group
    BWProperties,

    # Operators

    # Panels
    OBJECT_BooksGenerator,
)

def register():
    from bpy.utils import register_class
    for c in classes:
        register_class(c)
    
    bpy.types.Scene.booksgen = PointerProperty(type = BWProperties)

def unregister():
    from bpy.utils import unregister_class
    for c in reversed(classes):
        unregister_class(c)
    
    del bpy.types.Scene.bw

if __name__ == "__main__":
    register()