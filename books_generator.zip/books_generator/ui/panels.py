import bpy
from bpy.props import *
from bpy.types import (Panel, Menu, Operator, PropertyGroup)
import bpy.types

class OBJECT_BooksGenerator(Panel):
    bl_idname = "object.booksgen_generator"
    bl_label = "Books Generator"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Book Wizard"

    def draw(self, ctx):
        layout = self.layout
        scene = ctx.scene
        bw = scene.booksgen

        row = layout.row()
        row.label(text="Hello world!", icon='WORLD_DATA')

        row = layout.row()
        row.label(text="Active object is: " + obj.name)
        row = layout.row()
        row.prop(obj, "name")

        row = layout.row()
        row.operator("mesh.primitive_cube_add")
        